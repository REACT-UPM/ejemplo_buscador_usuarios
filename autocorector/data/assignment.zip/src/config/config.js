const CONFIG = {
  server_url: "https://dummyjson.com/users",
  num_items: 30,  
  use_server: true,
  loading_timeout_ms: 300
}

export default CONFIG;